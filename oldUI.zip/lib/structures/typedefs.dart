import 'package:flutter/material.dart';

typedef TryAgain = void Function(State state);
typedef TryLogin = void Function(State state);
///=============================================================================================
///typedef void VoidCallback();
/// typedef ValueChanged<T> = void Function(T value);
/// typedef ValueSetter<T> = void Function(T value);
/// typedef ValueGetter<T> = T Function();
/// typedef IterableFilter<T> = Iterable<T> Function(Iterable<T> input);
/// typedef AsyncCallback = Future<void> Function();
/// typedef AsyncValueSetter<T> = Future<void> Function(T value);
/// typedef AsyncValueGetter<T> = Future<T> Function();
//typedef EE<T extends WebAddress> = T;
