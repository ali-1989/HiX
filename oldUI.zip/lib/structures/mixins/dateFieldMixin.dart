
mixin DateFieldMixin {
  DateTime? date;
}